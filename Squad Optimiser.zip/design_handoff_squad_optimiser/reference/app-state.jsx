// Shared mini-app logic — each direction provides its own theme/components,
// but routing/state lives in <SquadApp theme={...} />.
// Themes are objects of CSS values; components reference them via `t.*`.

const { useState, useEffect, useMemo, useRef } = React;

// ─── Generic helper components used by all directions ───
function useAppState() {
  const [squad, setSquad] = useState([]);
  const [route, setRoute] = useState({ name: 'squad' }); // {name, params}
  const nav = (name, params) => setRoute({ name, params });

  const addPlayer = (p) => {
    const id = 'p' + Math.random().toString(36).slice(2,8);
    setSquad(s => [...s, {...p, id}]);
    return id;
  };
  const updatePlayer = (id, patch) => setSquad(s => s.map(p => p.id===id?{...p,...patch}:p));
  const deletePlayer = (id) => setSquad(s => s.filter(p => p.id!==id));

  return { squad, setSquad, route, nav, addPlayer, updatePlayer, deletePlayer };
}

// Plan state with sensible defaults
function usePlanState(initialPlayerId) {
  const [selectedId, setSelectedId] = useState(initialPlayerId || null);
  const [drillRows, setDrillRows] = useState([
    { id:'d1', drillName:'Skill Drill', sessionCount:5, drillLevel:'Medium' }
  ]);
  const [talent, setTalent] = useState('Normal');
  const [drillLevel, setDrillLevel] = useState('Medium');
  const [twoxAd, setTwoxAd] = useState(false);
  const [style, setStyle] = useState('Hybrid');
  const [greens, setGreens] = useState(0);
  const [premium, setPremium] = useState(false);
  const [targetTier, setTargetTier] = useState(null);
  const [tierPoints, setTierPoints] = useState({ Stellar:60, Master:10, Elite:30 });

  return {
    selectedId, setSelectedId, drillRows, setDrillRows, talent, setTalent,
    drillLevel, setDrillLevel, twoxAd, setTwoxAd, style, setStyle, greens, setGreens,
    premium, setPremium, targetTier, setTargetTier, tierPoints, setTierPoints,
  };
}

window.useAppState = useAppState;
window.usePlanState = usePlanState;
