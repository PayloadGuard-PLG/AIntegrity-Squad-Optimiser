// Shared sample data + lightweight engine approximations for prototype use.
// Numbers are illustrative — close to the spec's XP model but simplified.

const TIER_INFO = {
  None:      { addition: 0,   cost: 0,   color: '#6b7280' },
  Rare:      { addition: 10,  cost: 100, color: '#60a5fa' },
  Elite:     { addition: 30,  cost: 90,  color: '#34d399' },
  Stellar:   { addition: 50,  cost: 50,  color: '#22d3ee' },
  Master:    { addition: 80,  cost: 25,  color: '#a78bfa' },
  Epic:      { addition: 120, cost: 15,  color: '#fb923c' },
  Legendary: { addition: 160, cost: 10,  color: '#fbbf24' },
};
const TIER_ORDER = ['None','Rare','Elite','Stellar','Master','Epic','Legendary'];

const TALENT_TIERS = ['FT1','FT2','FT3','Normal','Slow'];
const TALENT_MULT  = { FT1:1.5, FT2:1.25, FT3:1.1, Normal:1.0, Slow:0.7 };
const DRILL_LEVELS = ['Very Easy','Easy','Medium','Hard','Very Hard'];
const DRILL_LEVEL_MULT = { 'Very Easy':1.0, Easy:1.15, Medium:1.3, Hard:1.55, 'Very Hard':1.7 };

const AGE_MULT = {
  17:1.10, 18:1.0, 19:0.9, 20:0.55, 21:0.4, 22:0.32, 23:0.28, 24:0.24,
  25:0.22, 26:0.19, 27:0.16, 28:0.14, 29:0.12, 30:0.10
};
const ageMult = (a) => AGE_MULT[a] ?? AGE_MULT[Math.min(30, Math.max(17, a))] ?? 0.10;

const DRILLS = [
  { name:'Skill Drill',          type:'Attack',   stats:['CREATIVITY','DRIBBLING','PASSING'], baseLoss:2.5, isBase:true },
  { name:'Finishing School',     type:'Attack',   stats:['SHOOTING','FINISHING','HEADING'],   baseLoss:3.0, isBase:true },
  { name:'Wing Play',            type:'Attack',   stats:['CROSSING','PASSING','SPEED'],       baseLoss:2.75, isBase:true },
  { name:'Defensive Shape',      type:'Defence',  stats:['POSITIONING','MARKING','TACKLING'], baseLoss:2.5, isBase:true },
  { name:'Backline Press',       type:'Defence',  stats:['TACKLING','AGGRESSION','BRAVERY'],  baseLoss:3.0, isBase:true },
  { name:'Sweeper Drill',        type:'Defence',  stats:['POSITIONING','SPEED','MARKING'],    baseLoss:2.75, isBase:true },
  { name:'Stamina Run',          type:'Physical', stats:['STAMINA','FITNESS','SPEED'],        baseLoss:3.5, isBase:true },
  { name:'Strength Circuit',     type:'Physical', stats:['STRENGTH','AGILITY','FITNESS'],     baseLoss:3.25, isBase:true },
  { name:'Fast Counter-Attacks', type:'Attack',   stats:['SPEED','CREATIVITY','PASSING'],     baseLoss:3.75, isBase:false },
  { name:'Lab: Press Trap',      type:'Defence',  stats:['POSITIONING','TACKLING','SPEED'],   baseLoss:3.0, isBase:false },
];

const FAN_CLUB_REDUCTION = [0.10, 0.15, 0.20, 0.25, 0.50];

// Sample squad
const SAMPLE_SQUAD = [
  {
    id:'p1', name:'Marco Vela',    age:18, ovr:142, tier:'Stellar', roles:['ST','AMC'],
    talent:'FT1', mutant:true,
    stats:{CREATIVITY:140,DRIBBLING:155,PASSING:138,SHOOTING:150,FINISHING:160,CROSSING:120,
      HEADING:130,STRENGTH:115,SPEED:155,AGILITY:145,FITNESS:130,STAMINA:135,TACKLING:80,
      MARKING:75,POSITIONING:130,BRAVERY:120,AGGRESSION:110}
  },
  {
    id:'p2', name:'Kael Ortiz',    age:21, ovr:118, tier:'Elite',   roles:['MC','AMC'],
    talent:'FT2', mutant:false,
    stats:{CREATIVITY:135,DRIBBLING:120,PASSING:140,SHOOTING:100,FINISHING:90,CROSSING:115,
      HEADING:90,STRENGTH:105,SPEED:118,AGILITY:120,FITNESS:115,STAMINA:130,TACKLING:120,
      MARKING:108,POSITIONING:125,BRAVERY:110,AGGRESSION:100}
  },
  {
    id:'p3', name:'Lior Aren',     age:19, ovr:108, tier:'Rare',    roles:['DC','MC'],
    talent:'FT3', mutant:false,
    stats:{CREATIVITY:80,DRIBBLING:90,PASSING:115,SHOOTING:70,FINISHING:65,CROSSING:85,
      HEADING:130,STRENGTH:140,SPEED:105,AGILITY:108,FITNESS:120,STAMINA:120,TACKLING:135,
      MARKING:140,POSITIONING:130,BRAVERY:125,AGGRESSION:130}
  },
  {
    id:'p4', name:'Jin Park',      age:24, ovr:165, tier:'Master',  roles:['ML','AML'],
    talent:'Normal', mutant:false,
    stats:{CREATIVITY:160,DRIBBLING:175,PASSING:160,SHOOTING:140,FINISHING:135,CROSSING:170,
      HEADING:120,STRENGTH:130,SPEED:178,AGILITY:172,FITNESS:155,STAMINA:160,TACKLING:120,
      MARKING:115,POSITIONING:155,BRAVERY:140,AGGRESSION:130}
  },
  {
    id:'p5', name:'Tomás Ríos',    age:17, ovr:96,  tier:'None',    roles:['GK'],
    talent:'FT1', mutant:true,
    stats:{REFLEXES:110,AGILITY:105,ANTICIPATION:95,'RUSHING OUT':85,COMMUNICATION:90,
      THROWING:80,KICKING:95,PUNCHING:85,'AERIAL REACH':100,FITNESS:100}
  },
];

// Role essential stats — simplified
const ROLE_WHITE = {
  ST:  ['SHOOTING','FINISHING','HEADING','SPEED','STRENGTH','POSITIONING'],
  AMC: ['CREATIVITY','PASSING','DRIBBLING','SHOOTING','SPEED','AGILITY'],
  AMR: ['CREATIVITY','DRIBBLING','CROSSING','SPEED','PASSING','AGILITY'],
  AML: ['CREATIVITY','DRIBBLING','CROSSING','SPEED','PASSING','AGILITY'],
  MC:  ['PASSING','CREATIVITY','TACKLING','POSITIONING','STAMINA','DRIBBLING'],
  MR:  ['CROSSING','SPEED','PASSING','STAMINA','DRIBBLING','AGILITY'],
  ML:  ['CROSSING','SPEED','PASSING','STAMINA','DRIBBLING','AGILITY'],
  DC:  ['TACKLING','MARKING','POSITIONING','HEADING','STRENGTH','BRAVERY'],
  DR:  ['TACKLING','MARKING','SPEED','STAMINA','POSITIONING','CROSSING'],
  DL:  ['TACKLING','MARKING','SPEED','STAMINA','POSITIONING','CROSSING'],
  GK:  ['REFLEXES','AGILITY','ANTICIPATION','RUSHING OUT','COMMUNICATION','AERIAL REACH'],
};
const ROLE_GRID = [
  [null,'DR','DC','DL'],
  ['GK','MR','MC','ML'],
  [null,'AMR','AMC','AML'],
  [null,null,'ST',null],
];
const ROLE_ADJ = {
  GK:[],
  DR:['DC','MR'],DC:['DR','DL','MC'],DL:['DC','ML'],
  MR:['DR','MC','AMR'],MC:['DC','MR','ML','AMC'],ML:['DL','MC','AMC'/*-ish*/,'AML'],
  AMR:['MR','AMC'],AMC:['MC','AMR','AML','ST'],AML:['ML','AMC'],
  ST:['AMC'],
};

const STATS_OUTFIELD = ['CREATIVITY','DRIBBLING','PASSING','SHOOTING','FINISHING','CROSSING','HEADING','STRENGTH','SPEED','AGILITY','FITNESS','STAMINA','TACKLING','MARKING','POSITIONING','BRAVERY','AGGRESSION'];
const STATS_GK       = ['REFLEXES','AGILITY','ANTICIPATION','RUSHING OUT','COMMUNICATION','THROWING','KICKING','PUNCHING','AERIAL REACH','FITNESS'];

const ovrColor = (ovr) => ovr >= 150 ? '#22c55e' : ovr >= 100 ? '#6366f1' : '#f59e0b';

// Compute average stat (proxy for OVR)
function meanStat(stats) {
  const v = Object.values(stats);
  if (!v.length) return 0;
  return v.reduce((a,b)=>a+b,0)/v.length;
}

// Quick projection — simplified XP model for live preview
function projectPlan({ player, drillRows, talent, drillLevel, twoxAd, targetTier, greens, fanClubLevel = 0 }) {
  if (!player) return null;
  const stats = {...player.stats};
  const whites = new Set(player.roles.flatMap(r => ROLE_WHITE[r] || []));
  const am = ageMult(player.age);
  const tm = TALENT_MULT[talent] || 1;
  const dlm = DRILL_LEVEL_MULT[drillLevel] || 1;
  const adM = twoxAd ? 2 : 1;

  const steps = [];
  let beforeOvr = meanStat(stats);

  drillRows.forEach((row) => {
    const drill = DRILLS.find(d => d.name === row.drillName);
    if (!drill || !row.sessionCount) return;
    const ovrBefore = meanStat(stats);
    // distribute XP across drill stats, weighted by white/grey
    for (let s = 0; s < row.sessionCount; s++) {
      const starMult = Math.pow(0.85, s);
      drill.stats.forEach(stat => {
        if (!(stat in stats)) return;
        if (stats[stat] >= 180) return;
        const isWhite = whites.has(stat);
        const greyMult = isWhite ? 1 : 0.5;
        const baseTier = stats[stat] < 60 ? 8 : stats[stat] < 80 ? 10 : stats[stat] < 100 ? 20 :
                         stats[stat] < 120 ? 30 : stats[stat] < 140 ? 40 : stats[stat] < 160 ? 50 : 60;
        const xpFor1 = baseTier / (am * tm * greyMult * adM * dlm * starMult);
        // Each session yields ~baseXp=60 XP (calibration placeholder)
        const baseXpPerStat = 60 / drill.stats.length;
        const gainPct = baseXpPerStat / xpFor1;
        stats[stat] = Math.min(180, stats[stat] + gainPct);
      });
    }
    const ovrAfter = meanStat(stats);
    steps.push({
      kind: 'drill',
      label: drill.name,
      desc: `${drill.type} · ${row.sessionCount}× ${row.drillLevel}`,
      ovrBefore, ovrAfter,
      gain: ovrAfter - ovrBefore,
      resource: 'free',
      type: drill.type,
    });
  });

  if (targetTier && targetTier !== 'None') {
    const ovrBefore = meanStat(stats);
    const add = TIER_INFO[targetTier].addition;
    whites.forEach(stat => {
      if (stat in stats) stats[stat] = Math.min(340, stats[stat] + add);
    });
    const ovrAfter = meanStat(stats);
    steps.push({
      kind:'tier', label:`Tier → ${targetTier}`,
      desc:`+${add} per essential stat`,
      ovrBefore, ovrAfter, gain:ovrAfter-ovrBefore,
      resource:`${TIER_INFO[targetTier].cost} ${targetTier} pts`,
      tierColor: TIER_INFO[targetTier].color,
    });
  }

  if (greens && greens > 0) {
    const ovrBefore = meanStat(stats);
    steps.push({
      kind:'condition', label:`${greens} Greens`,
      desc:`+${Math.min(100, greens*15)}% condition restore`,
      ovrBefore, ovrAfter: ovrBefore, gain: 0,
      resource:`${greens} greens`,
    });
  }

  const finalOvr = meanStat(stats);
  return {
    steps,
    finalOvr,
    totalGain: finalOvr - beforeOvr,
    warnings: stats && Object.entries(stats).filter(([,v]) => v >= 180).map(([k]) => `${k} hit 180-rule cap`),
  };
}

// Drill efficiency for a player
function getBestDrills(player, fanClubLevel) {
  if (!player) return [];
  const whites = new Set(player.roles.flatMap(r => ROLE_WHITE[r] || []));
  const reduction = FAN_CLUB_REDUCTION[fanClubLevel] || 0;
  return DRILLS.filter(d => d.isBase).map(d => {
    const hits = d.stats.filter(s => whites.has(s)).length;
    const eff = hits / d.stats.length;
    const condCost = +(d.baseLoss * (1 - reduction)).toFixed(2);
    return {
      ...d,
      efficiency: Math.round(eff * 100),
      conditionCost: condCost,
      isZeroDrain: condCost === 0 || (fanClubLevel === 4 && d.baseLoss < 3.0),
      whiteHits: d.stats.map(s => ({stat:s, white:whites.has(s)})),
    };
  }).sort((a,b) => b.efficiency - a.efficiency || a.conditionCost - b.conditionCost);
}

Object.assign(window, {
  TIER_INFO, TIER_ORDER, TALENT_TIERS, TALENT_MULT, DRILL_LEVELS, DRILL_LEVEL_MULT,
  DRILLS, FAN_CLUB_REDUCTION, SAMPLE_SQUAD, ROLE_WHITE, ROLE_GRID, ROLE_ADJ,
  STATS_OUTFIELD, STATS_GK, ovrColor, meanStat, projectPlan, getBestDrills,
});
