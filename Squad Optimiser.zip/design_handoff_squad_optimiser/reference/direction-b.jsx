// Direction B — "Operator": pitch-black, tailored, mechanical-watch energy.
// Inspired by DarkVader avatar — confidence in restraint, exposed machinery,
// gunmetal navy as the only accent, mono metadata, sharp tailored geometry.

const { useState: useStateB, useMemo: useMemoB, useEffect: useEffectB } = React;

const themeB = {
  bg: '#000000',
  surface: '#0a0a0c',
  surface2: '#111114',
  surface3: '#16171c',
  hairline: 'rgba(255,255,255,0.06)',
  hairline2: 'rgba(255,255,255,0.12)',
  hairline3: 'rgba(255,255,255,0.20)',
  ink: '#f4f4f5',
  inkSec: '#a1a1aa',
  inkMuted: '#6b6b73',
  inkGhost: '#3a3a40',
  // Steel-navy as primary accent (gunmetal / cool armour)
  steel: '#5b6b8a',
  steelLight: '#9eb0d4',
  steelDeep: '#3d4a66',
  // Hot accents for warnings / standout
  hot: '#e8b466',
  pos: '#7eb89a',
  neg: '#c4756a',
  mono: '"JetBrains Mono", "SF Mono", ui-monospace, monospace',
  display: '"Inter Tight", "Inter", system-ui, sans-serif',
  body: '"Inter", system-ui, sans-serif',
};

// ─── Atoms ───
function MonoLabelB({ children, color, size=10, style={} }) {
  return <span style={{
    fontFamily: themeB.mono, fontSize:size, letterSpacing:1.4, textTransform:'uppercase',
    color: color || themeB.inkMuted, fontWeight:500, ...style,
  }}>{children}</span>;
}

function ChipB({ active, onClick, children, size='md' }) {
  return (
    <button onClick={onClick} style={{
      padding: size==='sm'?'5px 9px':'7px 11px',
      fontSize: size==='sm'?10:11,
      fontFamily: themeB.mono, letterSpacing:1, textTransform:'uppercase',
      background: active ? themeB.ink : 'transparent',
      color: active ? themeB.bg : themeB.inkSec,
      border: `1px solid ${active ? themeB.ink : themeB.hairline2}`,
      borderRadius: 0, cursor:'pointer', fontWeight:500,
      transition:'all 100ms', whiteSpace:'nowrap',
    }}>{children}</button>
  );
}

function CrossHair({ size=8, color }) {
  const c = color || themeB.hairline2;
  return (
    <svg width={size} height={size} viewBox="0 0 8 8" style={{flexShrink:0}}>
      <path d={`M0 4H${size} M4 0V${size}`} stroke={c} strokeWidth="0.7"/>
    </svg>
  );
}

function CornerB({ children, color, padding=14, style={} }) {
  const c = color || themeB.hairline3;
  return (
    <div style={{position:'relative', padding, ...style}}>
      <div style={{position:'absolute',top:0,left:0,width:10,height:10,borderTop:`1px solid ${c}`,borderLeft:`1px solid ${c}`}}/>
      <div style={{position:'absolute',top:0,right:0,width:10,height:10,borderTop:`1px solid ${c}`,borderRight:`1px solid ${c}`}}/>
      <div style={{position:'absolute',bottom:0,left:0,width:10,height:10,borderBottom:`1px solid ${c}`,borderLeft:`1px solid ${c}`}}/>
      <div style={{position:'absolute',bottom:0,right:0,width:10,height:10,borderBottom:`1px solid ${c}`,borderRight:`1px solid ${c}`}}/>
      {children}
    </div>
  );
}

// Big mechanical OVR readout — exposed-movement watch face
function OvrMovement({ from, to, gain, name, age, tier }) {
  const c = ovrColor(to);
  return (
    <div style={{
      position:'relative', padding:'18px 18px 16px',
      background: 'radial-gradient(ellipse at 70% -20%, #1c1f2c 0%, #050507 70%)',
      border:`1px solid ${themeB.hairline2}`,
      overflow:'hidden',
    }}>
      {/* Engraved guilloché */}
      <svg style={{position:'absolute',inset:0,width:'100%',height:'100%',pointerEvents:'none'}}>
        <defs>
          <pattern id="movGrid" width="14" height="14" patternUnits="userSpaceOnUse">
            <path d="M14 0H0V14" stroke="rgba(255,255,255,0.045)" strokeWidth="0.5" fill="none"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#movGrid)"/>
      </svg>
      {/* Decorative gear, tucked top-right */}
      <svg width="120" height="120" viewBox="0 0 60 60" style={{
        position:'absolute',top:-22,right:-22,opacity:0.18,
      }}>
        <g stroke={themeB.steelLight} strokeWidth="0.4" fill="none">
          <circle cx="30" cy="30" r="26"/>
          <circle cx="30" cy="30" r="20"/>
          <circle cx="30" cy="30" r="14"/>
          <circle cx="30" cy="30" r="6"/>
          {Array.from({length:24}).map((_,i)=>{
            const a=(i/24)*Math.PI*2; const x1=30+Math.cos(a)*26; const y1=30+Math.sin(a)*26;
            const x2=30+Math.cos(a)*29; const y2=30+Math.sin(a)*29;
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}/>;
          })}
          {Array.from({length:12}).map((_,i)=>{
            const a=(i/12)*Math.PI*2; const x1=30+Math.cos(a)*14; const y1=30+Math.sin(a)*14;
            const x2=30+Math.cos(a)*20; const y2=30+Math.sin(a)*20;
            return <line key={'i'+i} x1={x1} y1={y1} x2={x2} y2={y2}/>;
          })}
          <circle cx="30" cy="30" r="2" fill={themeB.steelLight}/>
        </g>
      </svg>

      <div style={{position:'relative'}}>
        {/* identity strip */}
        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:14}}>
          <CrossHair size={6} color={themeB.steelLight}/>
          <MonoLabelB color={themeB.steelLight} size={9}>SUBJECT · {tier?.toUpperCase() || 'NONE'} · AGE {age}</MonoLabelB>
        </div>

        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-end',gap:10}}>
          <div style={{minWidth:0,flex:1}}>
            <div style={{
              fontSize:14,color:themeB.inkSec,fontFamily:themeB.display,
              fontWeight:500,marginBottom:4,
            }}>{name}</div>
            <MonoLabelB size={9}>FINAL OVR</MonoLabelB>
            <div style={{
              fontSize:62, fontWeight:200, color:c, fontFamily:themeB.display,
              letterSpacing:-3, lineHeight:0.9, marginTop:4,
              fontVariantNumeric:'tabular-nums',
            }}>{to.toFixed(1)}</div>
          </div>
          <div style={{textAlign:'right',flexShrink:0}}>
            <MonoLabelB size={9}>FROM</MonoLabelB>
            <div style={{
              fontFamily:themeB.mono,fontSize:14,color:themeB.inkSec,marginTop:4,
              fontVariantNumeric:'tabular-nums',
            }}>{from.toFixed(1)}</div>
            <div style={{
              display:'inline-flex',alignItems:'center',gap:5,marginTop:8,
              padding:'4px 8px',background:'rgba(126,184,154,0.12)',
              border:`1px solid ${themeB.pos}55`,
            }}>
              <span style={{
                color:themeB.pos,fontFamily:themeB.mono,fontSize:11,fontWeight:600,
                fontVariantNumeric:'tabular-nums',letterSpacing:0.5,
              }}>▲ {gain.toFixed(1)}</span>
            </div>
          </div>
        </div>

        {/* Range bar */}
        <div style={{marginTop:14}}>
          <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}>
            <MonoLabelB size={8}>0</MonoLabelB>
            <MonoLabelB size={8}>200</MonoLabelB>
          </div>
          <div style={{position:'relative',height:3,background:themeB.surface3}}>
            <div style={{
              position:'absolute',left:0,top:0,bottom:0,
              width:`${Math.min(100,(from/200)*100)}%`,background:themeB.inkMuted,
            }}/>
            <div style={{
              position:'absolute',
              left:`${Math.min(100,(from/200)*100)}%`,
              width:`${Math.min(100,((to-from)/200)*100)}%`,
              top:-1,bottom:-1,background:c,
              boxShadow:`0 0 10px ${c}88`,
            }}/>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Header (tactical bar) ───
function HeaderB({ route, nav, title, sub, back }) {
  const tabs = [
    {id:'squad',label:'SQUAD'},
    {id:'plan',label:'PLAN'},
    {id:'drills',label:'DRILLS'},
  ];
  const showTabs = ['squad','plan','drills'].includes(route.name);
  return (
    <div style={{background:themeB.bg, borderBottom:`1px solid ${themeB.hairline}`}}>
      <div style={{display:'flex',alignItems:'center',padding:'12px 16px 14px',gap:10}}>
        {back && <button onClick={back} style={{
          background:'transparent',border:`1px solid ${themeB.hairline2}`,
          width:28,height:28,color:themeB.ink,cursor:'pointer',padding:0,
          fontFamily:themeB.mono,fontSize:14,
        }}>←</button>}
        <div style={{flex:1,minWidth:0}}>
          <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:2}}>
            <CrossHair size={6} color={themeB.steelLight}/>
            <MonoLabelB color={themeB.steelLight} size={9}>{sub || 'OPERATOR · 1.0'}</MonoLabelB>
          </div>
          <div style={{
            fontSize:21,fontWeight:600,color:themeB.ink,fontFamily:themeB.display,
            letterSpacing:-0.6,lineHeight:1,
          }}>{title || 'Squad Optimiser'}</div>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <span style={{
            width:6,height:6,borderRadius:3,background:themeB.pos,
            boxShadow:`0 0 8px ${themeB.pos}`,
          }}/>
          <MonoLabelB size={9}>LIVE</MonoLabelB>
        </div>
      </div>
      {showTabs && (
        <div style={{display:'flex',borderTop:`1px solid ${themeB.hairline}`}}>
          {tabs.map((t,i) => {
            const active = route.name === t.id;
            return (
              <button key={t.id} onClick={()=>nav(t.id)} style={{
                flex:1,padding:'12px 0',background: active?themeB.surface2:'transparent',
                border:'none',
                borderRight: i<tabs.length-1 ? `1px solid ${themeB.hairline}` : 'none',
                color:active?themeB.ink:themeB.inkMuted,
                fontFamily:themeB.mono,fontSize:11,letterSpacing:2,
                cursor:'pointer',position:'relative',
              }}>
                {t.label}
                {active && <div style={{
                  position:'absolute',top:0,left:0,right:0,height:1,background:themeB.steelLight,
                }}/>}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── Squad screen ───
function SquadScreenB({ state }) {
  const { squad, nav } = state;
  const summary = useMemoB(() => {
    if (!squad.length) return null;
    const totalOvr = squad.reduce((a,p)=>a+p.ovr,0);
    // Talent distribution
    const talentCounts = squad.reduce((acc,p)=>{ acc[p.talent]=(acc[p.talent]||0)+1; return acc; }, {});
    // Tier distribution
    const tierCounts = squad.reduce((acc,p)=>{ const k=p.tier||'None'; acc[k]=(acc[k]||0)+1; return acc; }, {});
    return {
      n: squad.length,
      avgOvr: Math.round(totalOvr/squad.length),
      totalOvr,
      avgAge: (squad.reduce((a,p)=>a+p.age,0)/squad.length).toFixed(1),
      mutants: squad.filter(p=>p.mutant).length,
      ft1: talentCounts.FT1 || 0,
      under20: squad.filter(p=>p.age<20).length,
      eliteUp: squad.filter(p=>['Stellar','Master','Epic','Legendary'].includes(p.tier)).length,
      talentCounts, tierCounts,
    };
  }, [squad]);

  return (
    <div style={{flex:1,overflow:'auto',background:themeB.bg,position:'relative'}}>
      <HeaderB route={state.route} nav={state.nav}/>

      {squad.length === 0 ? (
        <div style={{padding:'40px 20px'}}>
          <CornerB padding={30} color={themeB.hairline3}>
            <div style={{textAlign:'center'}}>
              <svg width="60" height="60" viewBox="0 0 60 60" style={{margin:'0 auto 22px',display:'block'}}>
                <g stroke={themeB.steelLight} strokeWidth="0.6" fill="none">
                  <rect x="8" y="8" width="44" height="44"/>
                  <rect x="14" y="14" width="32" height="32"/>
                  <rect x="22" y="22" width="16" height="16"/>
                  <line x1="0" y1="30" x2="60" y2="30" strokeOpacity="0.35"/>
                  <line x1="30" y1="0" x2="30" y2="60" strokeOpacity="0.35"/>
                  <circle cx="30" cy="30" r="2" fill={themeB.steelLight}/>
                </g>
              </svg>
              <MonoLabelB size={11} color={themeB.steelLight}>NO PERSONNEL ON FILE</MonoLabelB>
              <div style={{
                fontSize:24,color:themeB.ink,fontFamily:themeB.display,
                fontWeight:600,letterSpacing:-0.6,margin:'12px 0 10px',
              }}>Acquire your first asset.</div>
              <div style={{fontSize:13,color:themeB.inkMuted,lineHeight:1.55,maxWidth:260,margin:'0 auto 22px'}}>
                Track personnel, project investment outcomes, rank scenarios with surgical precision.
              </div>
              <button onClick={()=>nav('player-new')} style={{
                background:themeB.ink,color:themeB.bg,border:'none',
                padding:'13px 26px',fontFamily:themeB.mono,fontSize:11,letterSpacing:2,
                fontWeight:600,cursor:'pointer',
              }}>＋  ADD PLAYER</button>
            </div>
          </CornerB>

          <div style={{marginTop:20,display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
            {[
              ['01','PROJECT','Forecast OVR step-by-step.'],
              ['02','OPTIMISE','Find zero-drain drill paths.'],
              ['03','COMPARE','Rank players head-to-head.'],
              ['04','TIER','Plan upgrade investments.'],
            ].map(([n,t,d])=>(
              <div key={n} style={{
                border:`1px solid ${themeB.hairline}`,padding:'12px 12px',background:themeB.surface,
              }}>
                <MonoLabelB size={9} color={themeB.steelLight}>{n} / {t}</MonoLabelB>
                <div style={{fontSize:11.5,color:themeB.inkSec,marginTop:6,lineHeight:1.4}}>{d}</div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <>
          {/* Stat readout strip */}
          {summary && (
            <>
              <div style={{
                display:'grid',gridTemplateColumns:'repeat(4,1fr)',
                borderBottom:`1px solid ${themeB.hairline}`,
              }}>
                {[
                  ['ROSTER',summary.n,null],
                  ['AVG OVR',summary.avgOvr, ovrColor(summary.avgOvr)],
                  ['AVG AGE',summary.avgAge,null],
                  ['MUTANT',summary.mutants, summary.mutants>0?themeB.hot:null],
                ].map(([l,v,c],i)=>(
                  <div key={l} style={{
                    padding:'14px 10px',
                    borderRight: i<3?`1px solid ${themeB.hairline}`:'none',
                  }}>
                    <MonoLabelB size={9}>{l}</MonoLabelB>
                    <div style={{
                      fontFamily:themeB.display,fontSize:24,fontWeight:300,
                      color: c || themeB.ink,
                      letterSpacing:-0.5,marginTop:4,fontVariantNumeric:'tabular-nums',lineHeight:1,
                    }}>{v}</div>
                  </div>
                ))}
              </div>

              {/* SQUAD DNA — what two same-OVR squads actually differ in */}
              <div style={{
                padding:'14px 16px 12px',
                borderBottom:`1px solid ${themeB.hairline}`,
                background:'linear-gradient(180deg, rgba(91,107,138,0.05), transparent)',
              }}>
                <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:10}}>
                  <CrossHair size={6} color={themeB.steelLight}/>
                  <MonoLabelB size={9} color={themeB.steelLight}>SQUAD DNA · STRATEGIC SIGNATURE</MonoLabelB>
                </div>

                {/* Talent distribution bar */}
                <div style={{marginBottom:12}}>
                  <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}>
                    <MonoLabelB size={8}>TALENT MIX</MonoLabelB>
                    <MonoLabelB size={8}>{summary.ft1} FT1 · {summary.under20} U20</MonoLabelB>
                  </div>
                  <div style={{display:'flex',height:6,background:themeB.surface3,gap:1}}>
                    {TALENT_TIERS.map(t => {
                      const n = summary.talentCounts[t] || 0;
                      if (!n) return null;
                      const pct = (n/summary.n)*100;
                      const colors = {FT1:'#9eb0d4',FT2:'#7d8ba8',FT3:'#5b6b8a',Normal:'#3a3a40',Slow:'#c4756a'};
                      return (
                        <div key={t} title={`${t}: ${n}`} style={{
                          width:`${pct}%`,background:colors[t],position:'relative',
                        }}>
                          {pct > 14 && <span style={{
                            position:'absolute',top:8,left:0,right:0,textAlign:'center',
                            fontFamily:themeB.mono,fontSize:8,letterSpacing:0.6,
                            color:themeB.inkSec,whiteSpace:'nowrap',
                          }}>{t}·{n}</span>}
                        </div>
                      );
                    })}
                  </div>
                  <div style={{height:14}}/>
                </div>

                {/* Tier ladder */}
                <div style={{marginBottom:12}}>
                  <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}>
                    <MonoLabelB size={8}>TIER LADDER</MonoLabelB>
                    <MonoLabelB size={8}>{summary.eliteUp}/{summary.n} ELITE+</MonoLabelB>
                  </div>
                  <div style={{display:'flex',gap:2}}>
                    {TIER_ORDER.map(t => {
                      const n = summary.tierCounts[t] || 0;
                      const c = TIER_INFO[t].color;
                      return (
                        <div key={t} style={{
                          flex:1, height:24, position:'relative',
                          background: n>0 ? c+'33' : 'transparent',
                          border:`1px solid ${n>0?c+'66':themeB.hairline}`,
                          display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',
                        }}>
                          <span style={{
                            fontFamily:themeB.mono,fontSize:10,fontWeight:600,
                            color: n>0?c:themeB.inkGhost,
                            fontVariantNumeric:'tabular-nums',lineHeight:1,
                          }}>{n}</span>
                          <span style={{
                            fontFamily:themeB.mono,fontSize:6,letterSpacing:0.5,
                            color: n>0?c:themeB.inkGhost,marginTop:2,
                          }}>{t.slice(0,3).toUpperCase()}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Age curve micro-chart */}
                <div>
                  <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}>
                    <MonoLabelB size={8}>AGE CURVE</MonoLabelB>
                    <MonoLabelB size={8}>17 ─ 30+</MonoLabelB>
                  </div>
                  <svg viewBox="0 0 200 30" style={{width:'100%',height:30,display:'block'}} preserveAspectRatio="none">
                    {/* Vertical hairlines at age markers */}
                    {[17,20,23,26,30].map(a => {
                      const x = ((a-17)/(30-17))*200;
                      return <line key={a} x1={x} y1={0} x2={x} y2={30} stroke={themeB.hairline} strokeWidth="0.5"/>;
                    })}
                    {squad.map((p,i) => {
                      const x = ((Math.min(30,p.age)-17)/(30-17))*200;
                      const r = p.ovr >= 150 ? 3 : p.ovr >= 100 ? 2.4 : 2;
                      const c = ovrColor(p.ovr);
                      return (
                        <g key={p.id}>
                          <circle cx={x} cy={15} r={r+1} fill={c} fillOpacity="0.15"/>
                          <circle cx={x} cy={15} r={r} fill={c}/>
                          {p.mutant && <circle cx={x} cy={15} r={r+2} fill="none" stroke={themeB.hot} strokeWidth="0.6"/>}
                        </g>
                      );
                    })}
                  </svg>
                </div>
              </div>
            </>
          )}

          <div style={{
            display:'flex',alignItems:'center',justifyContent:'space-between',
            padding:'16px 16px 10px',
          }}>
            <MonoLabelB size={10} color={themeB.steelLight}>ROSTER · {squad.length} ON FILE</MonoLabelB>
            <MonoLabelB size={9}>SORT: OVR ▼</MonoLabelB>
          </div>

          <div style={{padding:'0 12px 100px'}}>
            {squad.map((p,i) => (
              <button key={p.id} onClick={()=>state.nav('player-edit',{id:p.id})} style={{
                width:'100%',display:'block',background:themeB.surface,
                border:`1px solid ${themeB.hairline}`,
                borderTop: i>0?'none':`1px solid ${themeB.hairline}`,
                padding:'12px 14px',textAlign:'left',cursor:'pointer',
              }}>
                <div style={{display:'flex',alignItems:'center',gap:14}}>
                  <MonoLabelB size={9} style={{width:20}}>{String(i+1).padStart(2,'0')}</MonoLabelB>
                  <div style={{
                    minWidth:48,height:48,
                    border:`1px solid ${ovrColor(p.ovr)}66`,
                    background:`${ovrColor(p.ovr)}11`,
                    display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',
                  }}>
                    <div style={{
                      fontFamily:themeB.display,fontWeight:300,fontSize:18,
                      color:ovrColor(p.ovr),lineHeight:1,fontVariantNumeric:'tabular-nums',
                    }}>{p.ovr}</div>
                    <MonoLabelB size={7} color={`${ovrColor(p.ovr)}aa`} style={{marginTop:2,letterSpacing:0.8}}>OVR</MonoLabelB>
                  </div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{
                      fontSize:15,fontWeight:600,color:themeB.ink,fontFamily:themeB.display,
                      letterSpacing:-0.2,marginBottom:4,
                    }}>{p.name}</div>
                    <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap'}}>
                      <span style={{
                        fontFamily:themeB.mono,fontSize:9,letterSpacing:1.2,color:themeB.steelLight,
                      }}>{p.roles.join('·')}</span>
                      <span style={{color:themeB.inkGhost}}>/</span>
                      <span style={{fontFamily:themeB.mono,fontSize:9,letterSpacing:1.2,color:themeB.inkMuted}}>
                        {p.age}Y · {p.tier.toUpperCase()}
                      </span>
                      {p.mutant && <span style={{
                        fontFamily:themeB.mono,fontSize:8,letterSpacing:1,color:themeB.hot,
                        padding:'1px 5px',border:`1px solid ${themeB.hot}55`,marginLeft:4,
                      }}>MUTANT</span>}
                    </div>
                  </div>
                  <span style={{color:themeB.inkMuted,fontFamily:themeB.mono,fontSize:14}}>›</span>
                </div>
              </button>
            ))}
          </div>

          <button onClick={()=>state.nav('player-new')} style={{
            position:'absolute',bottom:18,left:16,right:16,
            background:themeB.ink,color:themeB.bg,border:'none',padding:'14px 0',
            fontFamily:themeB.mono,fontSize:11,letterSpacing:2.5,fontWeight:600,
            cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:8,
            boxShadow:'0 -10px 30px rgba(0,0,0,0.8)',
          }}>
            <span style={{fontSize:14,fontWeight:300}}>＋</span> ADD PLAYER
          </button>
        </>
      )}
    </div>
  );
}

// ─── Plan screen — HERO ───
function PlanScreenB({ state }) {
  const { squad, nav } = state;
  const cache = window.__planB = window.__planB || {};
  const [selectedId, setSelectedId] = useStateB(cache.selectedId || squad[0]?.id || null);
  const [drillRows, setDrillRows] = useStateB(cache.drillRows || [
    { id:'d1', drillName:'Skill Drill', sessionCount:6 },
    { id:'d2', drillName:'Stamina Run', sessionCount:4 },
  ]);
  const [talent, setTalent] = useStateB(cache.talent || 'FT1');
  const [drillLevel, setDrillLevel] = useStateB(cache.drillLevel || 'Medium');
  const [twoxAd, setTwoxAd] = useStateB(cache.twoxAd ?? true);
  const [styleX, setStyleX] = useStateB(cache.styleX || 'Hybrid');
  const [greens, setGreens] = useStateB(cache.greens ?? 4);
  const [premium, setPremium] = useStateB(cache.premium ?? true);
  const [targetTier, setTargetTier] = useStateB(cache.targetTier || 'Master');
  const [section, setSection] = useStateB('drills');

  useEffectB(()=>{
    Object.assign(cache, {selectedId, drillRows, talent, drillLevel, twoxAd, styleX, greens, premium, targetTier});
  });

  const player = squad.find(p => p.id === selectedId);
  const projection = useMemoB(() => {
    if (!player) return null;
    return projectPlan({ player, drillRows, talent, drillLevel, twoxAd, targetTier, greens });
  }, [player, drillRows, talent, drillLevel, twoxAd, targetTier, greens]);

  const setRow = (id,patch) => setDrillRows(rs => rs.map(r => r.id===id?{...r,...patch}:r));
  const addRow = () => setDrillRows(rs => [...rs,{id:'d'+Date.now(),drillName:'Skill Drill',sessionCount:3}]);
  const removeRow = (id) => setDrillRows(rs => rs.filter(r => r.id!==id));

  if (!player) {
    return (
      <div style={{flex:1,overflow:'auto',background:themeB.bg}}>
        <HeaderB route={state.route} nav={state.nav}/>
        <div style={{padding:'60px 24px',textAlign:'center'}}>
          <MonoLabelB color={themeB.steelLight}>NO ASSET SELECTED</MonoLabelB>
          <div style={{fontSize:18,color:themeB.ink,fontFamily:themeB.display,marginTop:12,marginBottom:18}}>
            Add a player to begin planning.
          </div>
          <button onClick={()=>nav('player-new')} style={{
            background:themeB.ink,color:themeB.bg,border:'none',padding:'12px 22px',
            fontFamily:themeB.mono,fontSize:11,letterSpacing:2,fontWeight:600,cursor:'pointer',
          }}>＋ ADD PLAYER</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{flex:1,overflow:'auto',background:themeB.bg,paddingBottom:30}}>
      <HeaderB route={state.route} nav={state.nav}/>

      {/* Player tabs */}
      {squad.length > 1 && (
        <div style={{display:'flex',gap:0,overflowX:'auto',
          borderBottom:`1px solid ${themeB.hairline}`,paddingLeft:8,
        }}>
          {squad.map(p => {
            const sel = p.id===selectedId;
            return (
              <button key={p.id} onClick={()=>setSelectedId(p.id)} style={{
                flexShrink:0,background:'transparent',border:'none',cursor:'pointer',
                padding:'10px 14px',
                borderBottom: sel?`2px solid ${themeB.steelLight}`:'2px solid transparent',
                marginBottom:-1,textAlign:'left',
              }}>
                <div style={{
                  fontSize:12,color:sel?themeB.ink:themeB.inkMuted,
                  fontWeight:sel?600:400,fontFamily:themeB.display,marginBottom:2,
                }}>{p.name}</div>
                <MonoLabelB size={8}>{p.ovr} · {p.roles[0]}</MonoLabelB>
              </button>
            );
          })}
        </div>
      )}

      <div style={{padding:'14px 12px 0'}}>
        <OvrMovement
          from={player.ovr} to={projection.finalOvr} gain={projection.totalGain}
          name={player.name} age={player.age} tier={player.tier}
        />
      </div>

      {/* Step rail — execution sequence */}
      <div style={{padding:'18px 16px 6px'}}>
        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:12}}>
          <MonoLabelB color={themeB.steelLight}>EXECUTION SEQUENCE</MonoLabelB>
          <div style={{flex:1,height:1,background:themeB.hairline}}/>
          <MonoLabelB>{projection.steps.length} STEPS</MonoLabelB>
        </div>

        <div style={{position:'relative',paddingLeft:22}}>
          <div style={{position:'absolute',left:6,top:8,bottom:8,width:1,background:themeB.hairline2}}/>
          {projection.steps.map((s,i)=>{
            const accent = s.kind==='drill'?themeB.steelLight:s.kind==='tier'?(s.tierColor||themeB.hot):themeB.pos;
            return (
              <div key={i} style={{position:'relative',marginBottom:8}}>
                <div style={{
                  position:'absolute',left:-19,top:7,width:13,height:13,
                  border:`1px solid ${accent}`,background:themeB.bg,
                  display:'flex',alignItems:'center',justifyContent:'center',
                }}>
                  <div style={{width:5,height:5,background:accent}}/>
                </div>
                <div style={{
                  border:`1px solid ${themeB.hairline2}`,background:themeB.surface,
                  padding:'10px 12px',display:'flex',alignItems:'center',gap:10,
                }}>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:3}}>
                      <MonoLabelB size={9} color={accent}>{s.kind.toUpperCase()}</MonoLabelB>
                      <span style={{color:themeB.inkGhost,fontSize:11}}>·</span>
                      <span style={{fontSize:13,fontWeight:600,color:themeB.ink,fontFamily:themeB.display}}>
                        {s.label}
                      </span>
                    </div>
                    <div style={{fontFamily:themeB.mono,fontSize:10,color:themeB.inkMuted,letterSpacing:0.4}}>
                      {s.desc}
                    </div>
                  </div>
                  <div style={{textAlign:'right'}}>
                    <div style={{fontFamily:themeB.mono,fontSize:10,color:themeB.inkMuted,fontVariantNumeric:'tabular-nums'}}>
                      {s.ovrBefore.toFixed(1)} → {s.ovrAfter.toFixed(1)}
                    </div>
                    <div style={{
                      fontFamily:themeB.display,fontSize:16,fontWeight:600,
                      color: s.gain>0?themeB.pos:themeB.inkMuted,marginTop:2,
                      fontVariantNumeric:'tabular-nums',letterSpacing:-0.3,
                    }}>{s.gain>0?'+':''}{s.gain.toFixed(1)}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {projection.warnings && projection.warnings.length > 0 && (
          <div style={{
            marginTop:6,padding:'10px 12px',
            border:`1px solid ${themeB.neg}55`,background:'rgba(196,117,106,0.08)',
            display:'flex',gap:8,alignItems:'flex-start',
          }}>
            <MonoLabelB size={10} color={themeB.neg}>WARN</MonoLabelB>
            <div style={{fontSize:11,color:themeB.inkSec,lineHeight:1.4}}>{projection.warnings.join(' · ')}</div>
          </div>
        )}
      </div>

      {/* Configurator section toggle */}
      <div style={{padding:'24px 16px 0'}}>
        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:14}}>
          <MonoLabelB color={themeB.steelLight}>CONFIGURATION</MonoLabelB>
          <div style={{flex:1,height:1,background:themeB.hairline}}/>
          {['drills','resources','tier'].map(s => (
            <button key={s} onClick={()=>setSection(s)} style={{
              background:'transparent',border:'none',cursor:'pointer',padding:0,marginLeft:10,
              color:section===s?themeB.ink:themeB.inkMuted,
              fontFamily:themeB.mono,fontSize:10,letterSpacing:1.4,
              borderBottom: section===s?`1px solid ${themeB.steelLight}`:'1px solid transparent',
              paddingBottom:2,textTransform:'uppercase',
            }}>{s}</button>
          ))}
        </div>

        {section==='drills' && (
          <>
            <div style={{display:'grid',gridTemplateColumns:'1fr',gap:14,marginBottom:16}}>
              <div>
                <MonoLabelB>TALENT</MonoLabelB>
                <div style={{display:'flex',gap:5,marginTop:6,flexWrap:'wrap'}}>
                  {TALENT_TIERS.map(t => (
                    <ChipB key={t} active={talent===t} onClick={()=>setTalent(t)}>{t}</ChipB>
                  ))}
                </div>
              </div>
              <div>
                <MonoLabelB>DRILL LEVEL</MonoLabelB>
                <div style={{display:'flex',gap:5,marginTop:6,flexWrap:'wrap'}}>
                  {DRILL_LEVELS.map(l => (
                    <ChipB key={l} active={drillLevel===l} onClick={()=>setDrillLevel(l)}>{l}</ChipB>
                  ))}
                </div>
              </div>
            </div>

            <button onClick={()=>setTwoxAd(!twoxAd)} style={{
              width:'100%',display:'flex',alignItems:'center',gap:12,
              background:twoxAd?themeB.surface2:themeB.surface,
              border:`1px solid ${twoxAd?themeB.hot:themeB.hairline2}`,
              padding:'10px 12px',cursor:'pointer',marginBottom:18,
            }}>
              <div style={{
                width:14,height:14,
                background:twoxAd?themeB.hot:'transparent',
                border:`1px solid ${twoxAd?themeB.hot:themeB.inkMuted}`,
              }}/>
              <span style={{
                fontFamily:themeB.mono,fontSize:11,letterSpacing:1.4,
                color:twoxAd?themeB.hot:themeB.inkSec,
              }}>2× AD MULTIPLIER</span>
              <span style={{flex:1}}/>
              <MonoLabelB size={9}>×2.00 XP</MonoLabelB>
            </button>

            <MonoLabelB>SESSIONS</MonoLabelB>
            <div style={{marginTop:8}}>
              {drillRows.map((row,idx) => {
                const drill = DRILLS.find(d=>d.name===row.drillName);
                const tc = drill?.type==='Attack'?themeB.steelLight:drill?.type==='Defence'?'#86c5d6':themeB.hot;
                return (
                  <div key={row.id} style={{
                    border:`1px solid ${themeB.hairline2}`,marginBottom:6,background:themeB.surface,
                  }}>
                    <div style={{
                      display:'flex',alignItems:'center',gap:8,padding:'9px 12px',
                      borderBottom:`1px solid ${themeB.hairline}`,
                    }}>
                      <MonoLabelB size={9} style={{minWidth:20}}>{String(idx+1).padStart(2,'0')}</MonoLabelB>
                      <span style={{
                        fontFamily:themeB.mono,fontSize:9,letterSpacing:1.2,color:tc,
                        padding:'2px 6px',border:`1px solid ${tc}55`,
                      }}>{drill?.type?.toUpperCase()}</span>
                      <div style={{flex:1,fontSize:13,color:themeB.ink,fontWeight:500,fontFamily:themeB.display}}>
                        {drill?.name}
                      </div>
                      <button onClick={()=>removeRow(row.id)} style={{
                        background:'transparent',border:'none',color:themeB.inkMuted,
                        cursor:'pointer',fontSize:14,padding:'0 4px',
                      }}>×</button>
                    </div>
                    <div style={{display:'flex',gap:5,padding:'8px 10px',overflowX:'auto'}}>
                      {DRILLS.filter(d=>d.isBase).map(d => (
                        <ChipB key={d.name} size="sm" active={row.drillName===d.name}
                          onClick={()=>setRow(row.id,{drillName:d.name})}>{d.name}</ChipB>
                      ))}
                    </div>
                    <div style={{display:'flex',alignItems:'stretch',borderTop:`1px solid ${themeB.hairline}`}}>
                      <button onClick={()=>setRow(row.id,{sessionCount:Math.max(0,row.sessionCount-1)})} style={{
                        flex:'0 0 38px',background:themeB.surface,border:'none',
                        borderRight:`1px solid ${themeB.hairline}`,
                        color:themeB.ink,fontFamily:themeB.mono,fontSize:14,cursor:'pointer',
                      }}>−</button>
                      <div style={{flex:1,padding:'10px 14px',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
                        <MonoLabelB size={9}>SESSIONS</MonoLabelB>
                        <span style={{
                          fontFamily:themeB.display,fontSize:18,color:themeB.ink,
                          fontWeight:300,fontVariantNumeric:'tabular-nums',
                        }}>{String(row.sessionCount).padStart(2,'0')}</span>
                      </div>
                      <button onClick={()=>setRow(row.id,{sessionCount:row.sessionCount+1})} style={{
                        flex:'0 0 38px',background:themeB.surface,border:'none',
                        borderLeft:`1px solid ${themeB.hairline}`,
                        color:themeB.ink,fontFamily:themeB.mono,fontSize:14,cursor:'pointer',
                      }}>+</button>
                    </div>
                  </div>
                );
              })}
              <button onClick={addRow} style={{
                width:'100%',background:'transparent',border:`1px dashed ${themeB.hairline2}`,
                padding:'10px',color:themeB.inkSec,fontFamily:themeB.mono,fontSize:11,
                letterSpacing:1.4,cursor:'pointer',
              }}>＋  ADD DRILL</button>
            </div>
          </>
        )}

        {section==='resources' && (
          <>
            <div style={{marginBottom:18}}>
              <MonoLabelB>STYLE</MonoLabelB>
              <div style={{display:'flex',gap:5,marginTop:6}}>
                {['FTP','Hybrid','PTW'].map(s => (
                  <ChipB key={s} active={styleX===s} onClick={()=>setStyleX(s)}>{s}</ChipB>
                ))}
              </div>
            </div>
            <div style={{marginBottom:18}}>
              <MonoLabelB>GREENS</MonoLabelB>
              <div style={{
                marginTop:6,display:'flex',alignItems:'stretch',
                border:`1px solid ${themeB.hairline2}`,
              }}>
                <button onClick={()=>setGreens(Math.max(0,greens-1))} style={{
                  flex:'0 0 36px',background:themeB.surface,border:'none',
                  borderRight:`1px solid ${themeB.hairline}`,color:themeB.ink,
                  fontFamily:themeB.mono,fontSize:14,cursor:'pointer',
                }}>−</button>
                <div style={{flex:1,padding:'10px 12px',display:'flex',alignItems:'center',gap:12}}>
                  <MonoLabelB size={9}>QTY</MonoLabelB>
                  <span style={{
                    fontFamily:themeB.display,fontSize:20,color:themeB.ink,fontWeight:300,
                    fontVariantNumeric:'tabular-nums',
                  }}>{greens}</span>
                  <span style={{flex:1}}/>
                  <MonoLabelB size={9} color={themeB.pos}>+{Math.min(100,greens*15)}% COND</MonoLabelB>
                </div>
                <button onClick={()=>setGreens(greens+1)} style={{
                  flex:'0 0 36px',background:themeB.surface,border:'none',
                  borderLeft:`1px solid ${themeB.hairline}`,color:themeB.ink,
                  fontFamily:themeB.mono,fontSize:14,cursor:'pointer',
                }}>+</button>
              </div>
            </div>
            <button onClick={()=>setPremium(!premium)} style={{
              width:'100%',display:'flex',alignItems:'center',gap:12,
              background:premium?themeB.surface2:themeB.surface,
              border:`1px solid ${premium?themeB.hot:themeB.hairline2}`,
              padding:'10px 12px',cursor:'pointer',
            }}>
              <div style={{
                width:14,height:14,
                background:premium?themeB.hot:'transparent',
                border:`1px solid ${premium?themeB.hot:themeB.inkMuted}`,
              }}/>
              <span style={{
                fontFamily:themeB.mono,fontSize:11,letterSpacing:1.4,
                color:premium?themeB.hot:themeB.inkSec,
              }}>PREMIUM SPONSOR</span>
            </button>
          </>
        )}

        {section==='tier' && (
          <>
            <MonoLabelB>TIER UPGRADE</MonoLabelB>
            <div style={{marginTop:8}}>
              {TIER_ORDER.filter(t=>t!=='None').map(t => {
                const info = TIER_INFO[t];
                const have = t==='Stellar'?60:t==='Master'?10:t==='Elite'?30:0;
                const can = have >= info.cost;
                const sel = targetTier === t;
                return (
                  <button key={t} onClick={()=>setTargetTier(sel?null:t)} style={{
                    width:'100%',display:'flex',alignItems:'stretch',gap:0,
                    background: sel?themeB.surface2:themeB.surface,
                    border:`1px solid ${sel?info.color:themeB.hairline2}`,
                    marginBottom:5,cursor:'pointer',padding:0,
                  }}>
                    <div style={{width:6,background:info.color}}/>
                    <div style={{padding:'10px 12px',flex:1,textAlign:'left'}}>
                      <div style={{display:'flex',alignItems:'baseline',gap:8,marginBottom:3}}>
                        <span style={{
                          fontFamily:themeB.display,fontSize:14,fontWeight:600,color:info.color,
                          letterSpacing:0.5,textTransform:'uppercase',
                        }}>{t}</span>
                        <MonoLabelB size={9}>+{info.addition}/STAT</MonoLabelB>
                      </div>
                      <div style={{
                        fontFamily:themeB.mono,fontSize:9,color:themeB.inkMuted,letterSpacing:0.6,
                      }}>NEED {info.cost} · HAVE {have} {can?'· READY':'· '+(info.cost-have)+' SHORT'}</div>
                    </div>
                    <div style={{
                      width:50,display:'flex',alignItems:'center',justifyContent:'center',
                      borderLeft:`1px solid ${themeB.hairline2}`,
                      color:can?themeB.pos:themeB.inkGhost,fontSize:18,fontWeight:300,
                    }}>{can?'✓':'·'}</div>
                  </button>
                );
              })}
            </div>
          </>
        )}

        <button onClick={()=>nav('compare')} style={{
          width:'100%',marginTop:24,
          background:'transparent',color:themeB.steelLight,
          border:`1px solid ${themeB.hairline3}`,
          padding:'12px 0',fontFamily:themeB.mono,fontSize:11,letterSpacing:2,
          fontWeight:600,cursor:'pointer',
        }}>HEAD-TO-HEAD COMPARISON →</button>
      </div>
    </div>
  );
}

// ─── Drills screen ───
function DrillsScreenB({ state }) {
  const { squad } = state;
  const [selectedId, setSelectedId] = useStateB(squad[0]?.id || null);
  const [fanLevel, setFanLevel] = useStateB(2);
  const player = squad.find(p => p.id === selectedId);
  const drills = useMemoB(()=>getBestDrills(player, fanLevel), [player, fanLevel]);

  return (
    <div style={{flex:1,overflow:'auto',background:themeB.bg,paddingBottom:30}}>
      <HeaderB route={state.route} nav={state.nav}/>
      <div style={{padding:'14px 16px'}}>
        {squad.length > 1 && (
          <>
            <MonoLabelB color={themeB.steelLight}>SUBJECT</MonoLabelB>
            <div style={{display:'flex',gap:5,overflowX:'auto',padding:'8px 0 14px'}}>
              {squad.map(p => (
                <ChipB key={p.id} active={p.id===selectedId} onClick={()=>setSelectedId(p.id)}>
                  {p.name}
                </ChipB>
              ))}
            </div>
          </>
        )}

        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
          <MonoLabelB color={themeB.steelLight}>FAN CLUB</MonoLabelB>
          <div style={{flex:1,height:1,background:themeB.hairline}}/>
          {fanLevel===4 && <MonoLabelB size={9} color={themeB.pos}>ZERO-DRAIN UNLOCKED</MonoLabelB>}
        </div>
        <div style={{display:'flex',gap:0,marginBottom:18,border:`1px solid ${themeB.hairline2}`}}>
          {[0,1,2,3,4].map(l => {
            const sel = fanLevel===l;
            return (
              <button key={l} onClick={()=>setFanLevel(l)} style={{
                flex:1,padding:'12px 0',background:sel?themeB.ink:'transparent',
                color:sel?themeB.bg:themeB.inkSec,border:'none',
                borderRight: l<4?`1px solid ${themeB.hairline2}`:'none',
                fontFamily:themeB.mono,fontSize:12,letterSpacing:1,cursor:'pointer',
                position:'relative',
              }}>
                L{l}
                {l===4 && !sel && <span style={{
                  position:'absolute',top:3,right:4,width:5,height:5,background:themeB.pos,borderRadius:3,
                }}/>}
              </button>
            );
          })}
        </div>

        {!player ? (
          <div style={{padding:'40px 0',textAlign:'center'}}>
            <MonoLabelB>SELECT A PLAYER</MonoLabelB>
          </div>
        ) : (
          <>
            <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:10}}>
              <MonoLabelB color={themeB.steelLight}>RECOMMENDATIONS</MonoLabelB>
              <div style={{flex:1,height:1,background:themeB.hairline}}/>
              <MonoLabelB size={9}>SORT EFF ▼</MonoLabelB>
            </div>
            {drills.map((d,i) => {
              const tc = d.type==='Attack'?themeB.steelLight:d.type==='Defence'?'#86c5d6':themeB.hot;
              return (
                <div key={d.name} style={{
                  border:`1px solid ${themeB.hairline2}`,
                  borderTop: i>0?'none':`1px solid ${themeB.hairline2}`,
                  background:themeB.surface,padding:'12px 14px',
                }}>
                  <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
                    <MonoLabelB size={9} style={{minWidth:18}}>{String(i+1).padStart(2,'0')}</MonoLabelB>
                    <span style={{
                      fontFamily:themeB.mono,fontSize:9,letterSpacing:1.2,color:tc,
                      padding:'2px 6px',border:`1px solid ${tc}55`,
                    }}>{d.type.toUpperCase()}</span>
                    <div style={{
                      flex:1,fontSize:14,color:themeB.ink,fontWeight:600,fontFamily:themeB.display,
                    }}>{d.name}</div>
                    {d.isZeroDrain && <span style={{
                      fontFamily:themeB.mono,fontSize:8,letterSpacing:1,color:themeB.pos,
                      padding:'2px 6px',border:`1px solid ${themeB.pos}55`,
                    }}>ZERO·DRAIN</span>}
                  </div>
                  <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:10}}>
                    {d.whiteHits.map(({stat,white}) => (
                      <span key={stat} style={{
                        fontFamily:themeB.mono,fontSize:9,letterSpacing:0.8,
                        color: white?themeB.steelLight:themeB.inkGhost,
                      }}>{white?'●':'○'} {stat}</span>
                    ))}
                  </div>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                    <div>
                      <div style={{display:'flex',justifyContent:'space-between',marginBottom:3}}>
                        <MonoLabelB size={9}>EFFICIENCY</MonoLabelB>
                        <span style={{
                          fontFamily:themeB.mono,fontSize:11,fontWeight:600,
                          color:themeB.pos,fontVariantNumeric:'tabular-nums',
                        }}>{d.efficiency}%</span>
                      </div>
                      <div style={{height:3,background:themeB.surface3}}>
                        <div style={{width:`${d.efficiency}%`,height:'100%',background:themeB.pos}}/>
                      </div>
                    </div>
                    <div>
                      <div style={{display:'flex',justifyContent:'space-between',marginBottom:3}}>
                        <MonoLabelB size={9}>COND·LOSS</MonoLabelB>
                        <span style={{
                          fontFamily:themeB.mono,fontSize:11,fontWeight:600,
                          color: d.conditionCost===0?themeB.pos:d.conditionCost<2?themeB.hot:themeB.neg,
                          fontVariantNumeric:'tabular-nums',
                        }}>{d.conditionCost.toFixed(2)}%</span>
                      </div>
                      <div style={{height:3,background:themeB.surface3}}>
                        <div style={{
                          width:`${Math.min(100,d.conditionCost*20)}%`,height:'100%',
                          background:d.conditionCost===0?themeB.pos:d.conditionCost<2?themeB.hot:themeB.neg,
                        }}/>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </>
        )}
      </div>
    </div>
  );
}

// ─── Compare screen ───
function CompareScreenB({ state }) {
  const { squad, nav } = state;
  const [selectedIds, setSelectedIds] = useStateB(squad.slice(0,2).map(p=>p.id));
  const [talent, setTalent] = useStateB('FT1');
  const [drillLevel, setDrillLevel] = useStateB('Medium');
  const [drillRows] = useStateB([
    {id:'d1', drillName:'Skill Drill', sessionCount:5},
    {id:'d2', drillName:'Stamina Run', sessionCount:3},
  ]);
  const [targetTier, setTargetTier] = useStateB('Master');

  const toggle = (id) => setSelectedIds(s => s.includes(id) ? s.filter(x=>x!==id) : [...s,id]);
  const results = useMemoB(()=>{
    return selectedIds.map(id => {
      const p = squad.find(x=>x.id===id);
      const proj = projectPlan({ player:p, drillRows, talent, drillLevel, twoxAd:false, targetTier, greens:0 });
      return { player:p, projection:proj };
    }).sort((a,b)=> b.projection.totalGain - a.projection.totalGain);
  }, [selectedIds, squad, drillRows, talent, drillLevel, targetTier]);

  const maxGain = Math.max(...results.map(r=>r.projection.totalGain), 0.1);

  return (
    <div style={{flex:1,overflow:'auto',background:themeB.bg,paddingBottom:30}}>
      <HeaderB route={state.route} nav={state.nav}
        title="HEAD-TO-HEAD" sub="COMPARATIVE ANALYSIS"
        back={()=>nav('plan')}/>
      <div style={{padding:'14px 16px'}}>
        <MonoLabelB color={themeB.steelLight}>SUBJECTS</MonoLabelB>
        <div style={{marginTop:8,marginBottom:18}}>
          {squad.map((p,i) => {
            const sel = selectedIds.includes(p.id);
            return (
              <button key={p.id} onClick={()=>toggle(p.id)} style={{
                width:'100%',display:'flex',alignItems:'center',gap:12,
                background:sel?themeB.surface2:themeB.surface,
                border:`1px solid ${sel?themeB.steelLight:themeB.hairline2}`,
                borderTop: i>0?'none':`1px solid ${sel?themeB.steelLight:themeB.hairline2}`,
                padding:'10px 12px',cursor:'pointer',textAlign:'left',
              }}>
                <div style={{
                  width:14,height:14,
                  background:sel?themeB.steelLight:'transparent',
                  border:`1px solid ${sel?themeB.steelLight:themeB.inkMuted}`,
                }}/>
                <div style={{
                  fontFamily:themeB.mono,fontSize:12,fontVariantNumeric:'tabular-nums',
                  color:ovrColor(p.ovr),minWidth:30,
                }}>{p.ovr}</div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:13,fontWeight:600,color:themeB.ink,fontFamily:themeB.display}}>
                    {p.name}
                  </div>
                  <MonoLabelB size={9}>{p.roles.join('·')} · {p.age}Y · {p.tier.toUpperCase()}</MonoLabelB>
                </div>
              </button>
            );
          })}
        </div>

        <MonoLabelB color={themeB.steelLight}>SHARED PARAMETERS</MonoLabelB>
        <div style={{marginTop:8,marginBottom:6}}>
          <MonoLabelB>TALENT</MonoLabelB>
          <div style={{display:'flex',gap:5,marginTop:6,flexWrap:'wrap'}}>
            {TALENT_TIERS.map(t => (<ChipB key={t} active={talent===t} onClick={()=>setTalent(t)}>{t}</ChipB>))}
          </div>
        </div>
        <div style={{marginTop:14,marginBottom:18}}>
          <MonoLabelB>TARGET TIER</MonoLabelB>
          <div style={{display:'flex',gap:5,marginTop:6,flexWrap:'wrap'}}>
            {TIER_ORDER.filter(t=>t!=='None').map(t => (
              <ChipB key={t} active={targetTier===t} onClick={()=>setTargetTier(targetTier===t?null:t)}>
                {t}
              </ChipB>
            ))}
          </div>
        </div>

        {selectedIds.length >= 2 && (
          <>
            <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:12}}>
              <MonoLabelB color={themeB.pos}>VERDICT</MonoLabelB>
              <div style={{flex:1,height:1,background:themeB.hairline}}/>
            </div>
            <CornerB padding={16} color={themeB.pos+'88'} style={{
              background:'rgba(126,184,154,0.05)',marginBottom:14,
            }}>
              <MonoLabelB size={10} color={themeB.pos}>RECOMMENDED ASSET</MonoLabelB>
              <div style={{
                fontSize:22,color:themeB.ink,fontFamily:themeB.display,
                fontWeight:600,letterSpacing:-0.4,marginTop:6,
              }}>{results[0].player.name}</div>
              <div style={{fontSize:12,color:themeB.inkSec,marginTop:6,lineHeight:1.5}}>
                Projects highest yield (<span style={{color:themeB.pos,fontFamily:themeB.mono,fontWeight:600}}>+{results[0].projection.totalGain.toFixed(1)} OVR</span>) under shared resources.
                Optimal value-per-resource at this talent + tier combination.
              </div>
            </CornerB>

            <div style={{marginBottom:8}}>
              <MonoLabelB color={themeB.steelLight}>RANKED RESULTS</MonoLabelB>
            </div>
            {results.map((r,i) => (
              <div key={r.player.id} style={{
                border:`1px solid ${themeB.hairline2}`,
                borderTop: i>0?'none':`1px solid ${themeB.hairline2}`,
                background:i===0?themeB.surface2:themeB.surface,
                padding:'12px 14px',
              }}>
                <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:8}}>
                  <div style={{
                    width:24,height:24,border:`1px solid ${i===0?themeB.pos:themeB.hairline3}`,
                    display:'flex',alignItems:'center',justifyContent:'center',
                    fontFamily:themeB.mono,fontSize:11,
                    color:i===0?themeB.pos:themeB.inkSec,fontWeight:600,
                  }}>#{i+1}</div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:14,fontWeight:600,color:themeB.ink,fontFamily:themeB.display}}>{r.player.name}</div>
                    <MonoLabelB size={9}>
                      OVR {r.player.ovr} → {r.projection.finalOvr.toFixed(1)}
                    </MonoLabelB>
                  </div>
                  <div style={{
                    fontFamily:themeB.display,fontSize:18,fontWeight:600,
                    color:themeB.pos,fontVariantNumeric:'tabular-nums',letterSpacing:-0.3,
                  }}>+{r.projection.totalGain.toFixed(1)}</div>
                </div>
                <div style={{height:3,background:themeB.surface3}}>
                  <div style={{
                    width:`${(r.projection.totalGain/maxGain)*100}%`,height:'100%',
                    background: i===0?themeB.pos:themeB.steel,
                  }}/>
                </div>
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
}

// ─── Player editor ───
function PlayerEditorB({ state, mode, playerId }) {
  const { squad, addPlayer, updatePlayer, deletePlayer, nav } = state;
  const existing = playerId && squad.find(p=>p.id===playerId);
  const [name, setName] = useStateB(existing?.name || '');
  const [roles, setRoles] = useStateB(existing?.roles || []);
  const [age, setAge] = useStateB(existing?.age || 18);
  const [ovr, setOvr] = useStateB(existing?.ovr || 100);
  const [tier, setTier] = useStateB(existing?.tier || 'None');
  const [mutant, setMutant] = useStateB(existing?.mutant || false);
  const [stats, setStats] = useStateB(existing?.stats || {});
  const [error, setError] = useStateB('');

  const isGK = roles.includes('GK');
  const statKeys = isGK ? STATS_GK : STATS_OUTFIELD;
  const whites = new Set(roles.flatMap(r=>ROLE_WHITE[r]||[]));

  const toggleRole = (r) => {
    if (!r) return;
    setError('');
    setRoles(rs => {
      if (rs.includes(r)) return rs.filter(x=>x!==r);
      if (r==='GK') return ['GK'];
      if (rs.includes('GK')) { setError('GK CANNOT COMBINE'); return rs; }
      if (rs.length >= 3) { setError('MAX 3 ROLES'); return rs; }
      if (rs.length && !rs.some(x => (ROLE_ADJ[r]||[]).includes(x))) {
        setError('NOT ADJACENT'); return rs;
      }
      return [...rs, r];
    });
  };

  const save = () => {
    if (!name.trim()) { setError('NAME REQUIRED'); return; }
    if (!roles.length) { setError('PICK A ROLE'); return; }
    const data = { name:name.trim(), roles, age:+age, ovr:+ovr, tier, mutant, stats, talent:'Normal' };
    if (existing) updatePlayer(existing.id, data);
    else addPlayer(data);
    nav('squad');
  };

  return (
    <div style={{flex:1,overflow:'auto',background:themeB.bg,paddingBottom:30}}>
      <HeaderB route={state.route} nav={state.nav}
        title={existing?'EDIT ASSET':'NEW ASSET'} sub={existing?'PROFILE · MUTABLE':'INTAKE FORM'}
        back={()=>nav('squad')}/>
      <div style={{padding:'14px 16px'}}>
        <MonoLabelB color={themeB.steelLight}>IDENTITY</MonoLabelB>
        <input value={name} onChange={e=>setName(e.target.value)} placeholder="Name" style={{
          width:'100%',background:themeB.surface,border:`1px solid ${themeB.hairline2}`,
          borderRadius:0,padding:'10px 12px',color:themeB.ink,fontSize:14,
          fontFamily:themeB.display,marginTop:8,marginBottom:6,boxSizing:'border-box',
        }}/>
        <div style={{display:'flex',gap:6,marginBottom:18}}>
          <div style={{flex:1}}>
            <MonoLabelB size={9}>AGE</MonoLabelB>
            <input type="number" value={age} onChange={e=>setAge(+e.target.value||17)} style={{
              width:'100%',background:themeB.surface,border:`1px solid ${themeB.hairline2}`,
              padding:'8px 12px',color:themeB.ink,fontSize:14,fontFamily:themeB.mono,
              marginTop:4,boxSizing:'border-box',
            }}/>
          </div>
          <div style={{flex:1}}>
            <MonoLabelB size={9}>OVR</MonoLabelB>
            <input type="number" value={ovr} onChange={e=>setOvr(+e.target.value||0)} style={{
              width:'100%',background:themeB.surface,border:`1px solid ${themeB.hairline2}`,
              padding:'8px 12px',color:themeB.ink,fontSize:14,fontFamily:themeB.mono,
              marginTop:4,boxSizing:'border-box',
            }}/>
          </div>
        </div>

        <MonoLabelB color={themeB.steelLight}>POSITION GRID <span style={{color:themeB.inkMuted}}>· MAX 3</span></MonoLabelB>
        <div style={{
          marginTop:8,marginBottom:6,padding:14,
          background:themeB.surface,border:`1px solid ${themeB.hairline2}`,
          display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:5,
        }}>
          {ROLE_GRID.flat().map((r, i) => {
            const sel = r && roles.includes(r);
            const isW = r && whites.has(r); // not really; placeholder
            return (
              <button key={i} onClick={()=>toggleRole(r)} disabled={!r} style={{
                padding:'12px 0',
                fontFamily:themeB.mono,fontSize:11,letterSpacing:1,
                background: r ? (sel?themeB.ink:'transparent') : 'transparent',
                color: r ? (sel?themeB.bg:themeB.inkSec) : 'transparent',
                border: r ? `1px solid ${sel?themeB.ink:themeB.hairline2}` : `1px solid transparent`,
                cursor:r?'pointer':'default',
              }}>{r||'·'}</button>
            );
          })}
        </div>
        {error && <MonoLabelB size={10} color={themeB.neg}>⚠ {error}</MonoLabelB>}

        <div style={{height:18}}/>
        <MonoLabelB color={themeB.steelLight}>TIER</MonoLabelB>
        <div style={{display:'flex',gap:5,flexWrap:'wrap',marginTop:8,marginBottom:14}}>
          {TIER_ORDER.map(t => {
            const c = TIER_INFO[t].color;
            const sel = tier===t;
            return (
              <button key={t} onClick={()=>setTier(t)} style={{
                padding:'7px 11px',fontSize:10,
                fontFamily:themeB.mono,letterSpacing:1,textTransform:'uppercase',
                background:sel?c:'transparent',
                color:sel?themeB.bg:c,
                border:`1px solid ${sel?c:c+'55'}`,
                cursor:'pointer',
              }}>{t}</button>
            );
          })}
        </div>

        <button onClick={()=>setMutant(!mutant)} style={{
          width:'100%',display:'flex',alignItems:'center',gap:12,
          background:mutant?themeB.surface2:themeB.surface,
          border:`1px solid ${mutant?themeB.hot:themeB.hairline2}`,
          padding:'10px 12px',cursor:'pointer',marginBottom:18,
        }}>
          <div style={{
            width:14,height:14,
            background:mutant?themeB.hot:'transparent',
            border:`1px solid ${mutant?themeB.hot:themeB.inkMuted}`,
          }}/>
          <span style={{
            fontFamily:themeB.mono,fontSize:11,letterSpacing:1.4,
            color:mutant?themeB.hot:themeB.inkSec,
          }}>★ MUTANT CANDIDATE</span>
        </button>

        {roles.length > 0 && (
          <>
            <MonoLabelB color={themeB.steelLight}>STATS <span style={{color:themeB.inkMuted}}>· ● ESSENTIAL</span></MonoLabelB>
            <div style={{
              marginTop:8,display:'grid',gridTemplateColumns:'1fr 1fr',gap:0,marginBottom:18,
              border:`1px solid ${themeB.hairline2}`,
            }}>
              {statKeys.map((s,i) => {
                const isW = whites.has(s);
                const isLastRow = i >= statKeys.length - 2;
                const isRight = i % 2 === 1;
                return (
                  <div key={s} style={{
                    padding:'8px 10px',
                    borderRight: !isRight ? `1px solid ${themeB.hairline}` : 'none',
                    borderBottom: !isLastRow ? `1px solid ${themeB.hairline}` : 'none',
                  }}>
                    <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:3}}>
                      <span style={{color:isW?themeB.steelLight:themeB.inkGhost,fontSize:8}}>●</span>
                      <MonoLabelB size={8} color={isW?themeB.steelLight:themeB.inkMuted}>{s}</MonoLabelB>
                    </div>
                    <input type="number" value={stats[s]||''} placeholder="0"
                      onChange={e=>setStats(st=>({...st,[s]:+e.target.value||0}))} style={{
                      width:'100%',background:'transparent',border:'none',
                      color:themeB.ink,fontSize:15,fontWeight:300,padding:0,
                      fontFamily:themeB.display,fontVariantNumeric:'tabular-nums',
                    }}/>
                  </div>
                );
              })}
            </div>
          </>
        )}

        <div style={{display:'flex',gap:6}}>
          <button onClick={save} style={{
            flex:1,background:themeB.ink,color:themeB.bg,border:'none',
            padding:'13px 0',fontFamily:themeB.mono,fontSize:11,letterSpacing:2,
            fontWeight:600,cursor:'pointer',
          }}>SAVE</button>
          {existing && (
            <button onClick={()=>{deletePlayer(existing.id);nav('squad');}} style={{
              flex:'0 0 100px',background:'transparent',color:themeB.neg,
              border:`1px solid ${themeB.neg}55`,
              padding:'13px 0',fontFamily:themeB.mono,fontSize:11,letterSpacing:2,
              fontWeight:600,cursor:'pointer',
            }}>DELETE</button>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Root ───
function SquadAppB({ initialSquad = [], __initialRoute, __initialPlayerId }) {
  const [squad, setSquad] = useStateB(initialSquad);
  const [route, setRoute] = useStateB(
    __initialRoute ? {name:__initialRoute, params: __initialPlayerId?{id:__initialPlayerId}:undefined} : {name:'squad'}
  );
  const nav = (name, params) => setRoute({name, params});

  const state = {
    squad, setSquad, route, nav,
    addPlayer: p => { const id='p'+Math.random().toString(36).slice(2,8); setSquad(s=>[...s,{...p,id}]); return id; },
    updatePlayer: (id,patch) => setSquad(s=>s.map(p=>p.id===id?{...p,...patch}:p)),
    deletePlayer: (id) => setSquad(s=>s.filter(p=>p.id!==id)),
  };

  let screen;
  if (route.name === 'squad') screen = <SquadScreenB state={state}/>;
  else if (route.name === 'plan') screen = <PlanScreenB state={state}/>;
  else if (route.name === 'drills') screen = <DrillsScreenB state={state}/>;
  else if (route.name === 'compare') screen = <CompareScreenB state={state}/>;
  else if (route.name === 'player-new') screen = <PlayerEditorB state={state} mode="new"/>;
  else if (route.name === 'player-edit') screen = <PlayerEditorB state={state} mode="edit" playerId={route.params?.id}/>;

  return (
    <div style={{
      width:'100%',height:'100%',display:'flex',flexDirection:'column',
      background:themeB.bg,color:themeB.ink,fontFamily:themeB.body,
      position:'relative',overflow:'hidden',
    }}>
      {screen}
    </div>
  );
}

window.SquadAppB = SquadAppB;
window.themeB = themeB;
