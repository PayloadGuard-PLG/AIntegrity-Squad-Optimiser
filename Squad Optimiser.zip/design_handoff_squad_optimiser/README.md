# Handoff: Squad Optimiser — Direction B (Console)

## Overview

Squad Optimiser is a **mobile companion app for football-management gamers** who manage 4–10 players (a "squad") and want to plan training investments precisely: which player to develop, what drills to run, what tier/talent path to commit to, and how it changes overall ratings (OVR) and stat splits.

This handoff is for **Direction B — "Console"** (also called "Operator"): a pitch-black, tailored, mechanical-watch-energy aesthetic. Restraint, exposed machinery, mono metadata, sharp geometry, gunmetal-navy as the only chromatic accent.

## About the Design Files

The files in `reference/` are **design references created in HTML** — React + inline-styles prototypes showing intended look and behavior. They are **not production code to copy directly**. Your task is to recreate these designs in your target environment (recommended: **React Native + Expo** for one codebase across iOS/Android, with EAS Update for OTA delivery), using the established patterns and libraries of that codebase.

The standalone HTML (`reference/Squad Optimiser Mobile (standalone).html`) opens in any browser and lets you click through all five screens of Direction B. Use it as the source of truth for layout, copy, and interaction.

## Fidelity

**High-fidelity.** Colors, typography, spacing, borders, and copy are final. Recreate pixel-perfectly using your codebase's component patterns. The only liberty: replace inline-styles with whatever your styling solution is (StyleSheet, Tamagui, Nativewind, Restyle, etc.) — keep the values identical.

## Screens / Views

Direction B has five primary screens, all rendered inside an iOS device frame at 390×844 (iPhone 14 / 15 dimensions). Tab bar bottom-pinned across Squad / Plan / Drills.

### 1. Squad — `route: 'squad'`
**Purpose:** Roster overview. The home screen.
- **Header:** Title "DOSSIER", subtitle "ACTIVE PERSONNEL · {N} ENTRIES", tab bar below.
- **Summary strip:** 4 stats — Total Players, Average OVR, Stellar count, Mutant count — rendered as huge mono numerals over tiny uppercase mono labels.
- **Player rows:** Each row shows OVR badge (large mono numeral, color-coded), name (display font, 16px), age + roles + tier badge + mutant star, and a chevron. 1px hairline divider between rows.
- **CTA pinned bottom:** "+ ADD PLAYER" — full-width, ink background, mono label letter-spacing 2.

### 2. Plan ★ HERO — `route: 'plan'`
**Purpose:** The core flow. Pick a player + a target tier, configure drill mix, and see projected OVR + stat deltas.
- **Header:** "INVESTMENT MODEL", subtitle "PROJECTION ENGINE".
- **Subject selector:** Horizontal scroll of player chips (mono, uppercase, 1px border, active = ink-on-bg).
- **Big OVR readout (mechanical-watch component):** Current OVR → projected OVR with an arrow. Gain in green mono. Player name + age + tier underneath.
- **Tier ladder:** Rare → Elite → Stellar → Master, each with cost/points required, owned-points readout, selection state shown via thicker hairline + ink fill.
- **Drill rows:** Editable list — drill name + session count. Add/remove buttons in mono.
- **Modifiers strip:** Talent (FT1/FT2/FT3), Drill Level (Easy/Medium/Hard), 2x Ad toggle, Style (Hybrid/Speed/Power), Greens (numeric), Premium toggle.
- **Stat-delta visualization:** Bars showing per-stat change from baseline → projected. Positive = pos green, negative = neg red.
- **CTA:** "COMPARE SCENARIOS" → goes to Compare screen.

### 3. Drills — `route: 'drills'`
**Purpose:** Reference for what each drill does.
- **Header:** "DRILL LIBRARY", subtitle "TRAINING PROTOCOLS".
- **Player selector** at top (same chip pattern as Plan).
- **Drill cards:** One per drill type (Skill, Power, Pace, Aerial, etc.). Each card shows the stats it boosts as a mini bar group with mono labels.

### 4. Compare — `route: 'compare'`
**Purpose:** Side-by-side projection of two players.
- **Header:** "HEAD-TO-HEAD", subtitle "COMPARATIVE ANALYSIS".
- **Subject selectors:** Two columns of player chips.
- **Stat grid:** Each row = one stat. Two columns of values + a divergence bar showing who's ahead and by how much.

### 5. Player Editor — `route: 'player-new' | 'player-edit'`
**Purpose:** Create or edit a player record.
- **Header:** "NEW ASSET" or "EDIT ASSET", subtitle "INTAKE FORM" or "PROFILE · MUTABLE".
- **Sections (mono uppercase headings, 1px hairline separator above each):**
  - IDENTITY: name, age, roles (multi-select chips), tier dropdown, mutant toggle, talent (FT1/2/3/Normal).
  - STATS: numeric inputs grid, 17 outfield stats or 10 GK stats. Mono labels.
- **CTA row:** "SAVE" (ink, full-width), "DELETE" (neg-red outline, only on edit).

## Interactions & Behavior

- **Navigation:** Single-stack — header back button (`‹`) returns to previous route. Tab bar swaps the root screen (squad / plan / drills). Compare and Player Editor are pushed routes.
- **Plan screen recalculation:** Every modifier change recomputes OVR projection synchronously. No loading states — the model is local.
- **Tier selection:** If the user doesn't have enough tier-points, the option is rendered greyed (`inkGhost`) with a strikethrough on the cost. Selecting a valid tier updates the OVR readout immediately.
- **Player chip scroll:** Snap-free horizontal scroll. Active chip uses inverted colors (ink bg, bg fg).
- **Editor save:** Validates name (non-empty) and stats (numeric, 0–200 range). On save → nav back to squad.
- **Empty state (no players):** Squad screen shows centered prompt with "+ ADD FIRST PLAYER" CTA.

## State Management

A single root `SquadAppB` component holds the squad array and route object. It builds an `appState` object with `{ squad, addPlayer, updatePlayer, deletePlayer, route, nav }` and passes it to each screen. In a real RN app:

- **Use Zustand or Jotai** for this — lightweight and matches the shape exactly. (Alternatively, React Context if you want zero deps.)
- **Persistence:** Squad and Plan-screen modifier values should persist locally — `AsyncStorage` (simple) or `MMKV` (faster).
- **Route state:** Use the navigation library you're already using. React Navigation's native stack is fine. The route name → screen mapping is in `direction-b.jsx` lines ~1369–1374.

State shape:
```ts
type Player = {
  id: string;
  name: string;
  roles: string[];        // e.g. ['ST','AMC'] or ['GK']
  age: number;
  ovr: number;
  tier: 'None'|'Rare'|'Elite'|'Stellar'|'Master';
  mutant: boolean;
  talent: 'FT1'|'FT2'|'FT3'|'Normal';
  stats: Record<string, number>;  // outfield: 17 keys; GK: 10 keys
};
```

Stat keys (outfield): `CREATIVITY, DRIBBLING, PASSING, SHOOTING, FINISHING, CROSSING, HEADING, STRENGTH, SPEED, AGILITY, FITNESS, STAMINA, TACKLING, MARKING, POSITIONING, BRAVERY, AGGRESSION`.
Stat keys (GK): `REFLEXES, AGILITY, ANTICIPATION, "RUSHING OUT", COMMUNICATION, THROWING, KICKING, PUNCHING, "AERIAL REACH", FITNESS`.

## Design Tokens

```js
// Colors
bg:        '#000000'   // pure black canvas
surface:   '#0a0a0c'   // primary card
surface2:  '#111114'   // raised card
surface3:  '#16171c'   // raised + active
hairline:  'rgba(255,255,255,0.06)'   // micro divider
hairline2: 'rgba(255,255,255,0.12)'   // standard border
hairline3: 'rgba(255,255,255,0.20)'   // emphasis border
ink:       '#f4f4f5'   // primary text (off-white)
inkSec:    '#a1a1aa'   // secondary text
inkMuted:  '#6b6b73'   // tertiary text / mono labels
inkGhost:  '#3a3a40'   // disabled

// Accents
steel:     '#5b6b8a'   // gunmetal navy — primary accent
steelLight:'#9eb0d4'   // accent highlight
steelDeep: '#3d4a66'   // accent shadow
hot:       '#e8b466'   // warning / standout (sparingly)
pos:       '#7eb89a'   // positive delta
neg:       '#c4756a'   // negative delta / destructive

// Typography
display: 'Inter Tight, Inter, system-ui, sans-serif'   // headings, names
body:    'Inter, system-ui, sans-serif'                // body text
mono:    'JetBrains Mono, SF Mono, ui-monospace, monospace'  // ALL labels, numerals

// Type scale
heading-l: 28px / weight 700 / letter-spacing -0.5
heading-m: 19px / weight 600 / letter-spacing -0.2
body:      14px / weight 400
caption:   12px / weight 500
mono-lbl:  10px / weight 500 / uppercase / letter-spacing 1.4
mono-tiny: 9px  / weight 500 / uppercase / letter-spacing 1.6

// Spacing scale (px)
4, 8, 10, 12, 14, 16, 18, 22, 26, 32, 48

// Borders & radii
hairline-width: 1px
border-radius:  0px (almost everywhere — sharp tailored geometry)
                exceptions: OVR badges (round), the dynamic-island visual (24px)

// Shadows
none, almost everywhere. The aesthetic is flat-on-black.
```

**Critical aesthetic rules:**
1. **No rounded corners** on cards, buttons, or inputs unless specifically noted. The look is tailored, not soft.
2. **Mono font for every label, numeral, button text, and caption.** Display/body fonts are reserved for player names and screen titles only.
3. **Letter-spacing on mono uppercase: 1.4–2.0px.** Not optional — it's the signature.
4. **Hairline borders, not solid.** 1px at 6%/12%/20% white opacity.
5. **One accent color (steel-navy).** Pos-green and neg-red appear only on data deltas.

## Assets

No image or icon assets ship with this design. All iconography is SVG drawn inline (chevrons, crosshairs, tier markers, dynamic-island, home indicator). Keep them as inline SVG in your RN app via `react-native-svg`.

The iOS device frame in the standalone HTML is purely for design presentation — your RN app runs natively, you don't need to recreate it.

## Files

In `reference/`:

- **`Squad Optimiser Mobile (standalone).html`** — Open in any browser. The full clickable prototype. Source of truth for visuals and interactions. Top-bar switcher between A/B/C — keep on **B**.
- **`direction-b.jsx`** — All B-direction React components: theme tokens, atoms (chips, mono labels, corner brackets, OVR readout), and the five screens. ~1389 lines. **Read this end-to-end before implementing.**
- **`ios-frame.jsx`** — iOS device chrome used in the prototype. You don't need to port this — it's just for the in-browser preview. Skip.
- **`data.jsx`** — Domain logic: tier definitions, drill definitions, OVR computation, stat-delta projection. **Port this verbatim** — it's the calculation engine and shouldn't change.
- **`app-state.jsx`** — The shared state shape (squad, route, nav) used across all three directions. Use as a model for your Zustand/Jotai store.

## Recommended Implementation Order

1. **Set up tokens** — Drop the design tokens above into `theme.ts` first. Match exactly.
2. **Port `data.jsx` to TypeScript** — pure functions, no UI. Validate with the same `SAMPLE_SQUAD` from `direction-b.jsx`.
3. **Build atoms** — `MonoLabel`, `Chip`, `CornerBrackets`, `OvrReadout`. These appear on every screen.
4. **Build Squad screen** — simplest layout, validates your atoms work in RN.
5. **Build Plan screen** — the hero, most complex. Save for last.
6. **Compare + Drills + Editor** — order doesn't matter once Plan is done.

## OTA / GitHub Actions

Recommended pipeline (assuming Expo + EAS):
- `main` push → `eas update --branch production` (OTA, ~2 min to all installs)
- Native version bump or new permission → `eas build` + store submit (less common)
- Use feature flags (`expo-config` extras or PostHog) for in-flight tweaks like density and hero-highlight.

## Iteration

This handoff is exportable now, but you can keep iterating on the design here:
- Ask for screen-level tweaks ("Compare screen — make the divergence bar thicker") and I'll update `direction-b.jsx`, regenerate the standalone, and refresh this handoff.
- Ask for a per-screen Claude Code prompt and I'll write a focused brief (component breakdown + token references) you can paste straight into Claude Code.
- Ask for additional states (loading, error, sync) — I'll add them to the prototype.
